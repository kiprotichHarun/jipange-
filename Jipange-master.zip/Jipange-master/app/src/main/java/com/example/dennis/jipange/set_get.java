package com.example.dennis.jipange;

/**
 * Created by dennis on 2/3/2018.
 */

public class set_get {
    String s,z,Name,Transport_From,Transport_To,Price,Transport_spinner,food_spinner,mealtime,drink_spinner,bill_spinner,hist,field,spin;
    public void setname(String Name)
    {
     this.Name = Name;
    }
    public  String getname()
    {
    return this.Name;
    }


    public void setfrom(String Transport_From)
    {
    this.Transport_From = Transport_From;
    }
    public String getfrom()
    {
        return this.Transport_From;
    }

    public void setto(String Transport_To)
    {
        this.Transport_To = Transport_To ;
    }
    public String getto()
    {
        return this.Transport_To;
    }

    public void setprice(String Price)
    {
        this.Price= Price;
    }
    public String getprice()
    {
        return this.Price;
    }

    public void setcat(String Transport_spinner)
   {
    this.Transport_spinner = Transport_spinner;
    }
   public String getcat()
    {
        return this.Transport_spinner;
    }

    public void setfood(String food_spinner)
    {
        this.food_spinner = food_spinner;
    }
    public String getfood()
    {
        return this.food_spinner;
    }

    public void setmeal(String mealtime)
    {
        this.mealtime = mealtime;
    }
    public String getmeal()
    {
        return this.mealtime;
    }

    public void setdrink(String  drink_spinner )
    {
        this.drink_spinner = drink_spinner;
    }
    public String getdrink()
    {
        return this.drink_spinner;
    }

    public void setbill(String bill_spinner)
    {
        this.bill_spinner = bill_spinner;
    }
    public String getbill()
    {
        return this.bill_spinner;
    }

    public void sethistory(String hist) {
        this.hist = hist;
    }
    public String gethistory()
    {
        return this.hist;
    }

    public void setfield(String field) {
        this.field = field;
    }
    public String getfield()
    {
        return  this.field;
    }

    public void setfields(String spin) {
        this.spin = spin;
    }
    public String getfields()
    {
        return this.spin;
    }

    public void setimageuri() {
    }

    public void setstat(String s) {
        this.s = s;
    }
    public String getstat()
    {return this.s;}

    public void setstatus(String z) {
        this.z = z;
    }
    public String getstatus()
    {
        return this.z;
    }
}
